<?php

namespace app\admin\model;

use think\Model;

class Alluser extends Model
{
    protected $table="pk_user";
    public function getList($data){
    	 (isset($data['username']) && !empty($data['username'])) ? $where1['username'] = ['like', '%' . $data['username'] . '%']:$where1=[];
        (isset($data['phone']) && !empty($data['phone'])) ? $where2['phone'] = ['like', '%' . $data['phone'] . '%']:$where2=[];
       
        $page=$this::order('uid desc')->where($where1)->where($where2)->paginate(20,false,['query'=>$data]);
        //获得分页的页码列表信息 并 传递给模版：
        $pagelist = $page -> render();
        return ['page'=>$page,'pagelist'=>$pagelist,'data'=>$data];
    }
}
