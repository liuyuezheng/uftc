<?php

namespace app\admin\model;

use think\Model;

class GoodsPics extends Model
{
    //
}
