<?php

namespace app\admin\model;

use think\Model;

class Password extends Model
{
    //
}
