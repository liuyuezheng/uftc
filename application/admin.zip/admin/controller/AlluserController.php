<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;
use think\Db;
use think\Session;

class AlluserController extends Controller
{
    public function index(Request $request)
    {
        $data['username']=$request->param('username');
        $data['phone']=$request->param('phone');
        $data['mg_name']=Session::get('mg_name');
        $data['mg_id']=Session::get('mg_id');
        $user_model=new \app\admin\model\Alluser();
        $shuju=$user_model->getlist($data);
        $this->assign('shuju',$shuju);
        return $this -> fetch();
    }
}
